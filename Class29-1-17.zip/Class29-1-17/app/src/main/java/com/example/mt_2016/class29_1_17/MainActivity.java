package com.example.mt_2016.class29_1_17;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.mt_2016.class29_1_17.databinding.maa;

public class MainActivity extends AppCompatActivity {

    private maa maa1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maa1 = DataBindingUtil.setContentView(this,R.layout.activity_main);

        maa1.mytext.setText("LO");

        getSupportFragmentManager().beginTransaction().replace(R.id.mfrag,new MyFragment()).commit();
    }
}
