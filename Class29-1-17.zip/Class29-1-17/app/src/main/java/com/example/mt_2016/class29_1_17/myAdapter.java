package com.example.mt_2016.class29_1_17;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.example.mt_2016.class29_1_17.databinding.maa;

import java.util.List;
import java.util.zip.Inflater;

/**
 * Created by MT-2016 on 29-Jan-17.
 */
public class myAdapter extends ArrayAdapter<String> {
    public Context context;
    private  maa behan;
    public myAdapter(Context context, int resource, List<String> objects) {
        super(context, resource, objects);
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        behan = DataBindingUtil.inflate(LayoutInflater.from(context),R.layout.activity_main,parent,false);
    return behan.getRoot();
    }
}
