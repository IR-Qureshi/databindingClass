package com.example.mt_2016.class29_1_17;


import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.Toast;

import com.example.mt_2016.class29_1_17.databinding.fragmentBind;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyFragment extends Fragment {

    private fragmentBind mfragmentBind;

    public MyFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mfragmentBind = DataBindingUtil.inflate(LayoutInflater.from(container.getContext()) ,R.layout.fragment_my, container, false);

        mfragmentBind.Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "Hogaya", Toast.LENGTH_SHORT).show();
            }
        });



    return mfragmentBind.getRoot();

    }

}
